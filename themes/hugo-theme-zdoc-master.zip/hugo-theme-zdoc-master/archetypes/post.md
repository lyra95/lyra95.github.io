---
author: "Hugo Authors"
title: "{{ replace .Name "-" " " | title }}"
description: ""
date: {{ .Date }}
draft: false
weight: 0
tags:
- 
image: "" # relative path to the static folder. The image is in the root/static/images folder.
enableToc: true
tocLevels: ["h2", "h3", "h4"]
---