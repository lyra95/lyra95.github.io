---
title: Blog
description: Blog list page
blogHeaderType: text
headerHeight: 112
header:
  - type: text
    paddingX: 50
    paddingY: 0
    align: center
    title:
      - Blog
    subtitle:
      - 
    spaceBetweenTitleSubtitle: 0
  
  - type: img
    imageSrc: images/header/background.png
    imageSize: initial
    imageRepeat: no-repeat
    imagePosition: center
    height: 170
    paddingX: 50
    paddingY: 0
    align: center
    title:
      - 
    subtitle:
      - 
    titleShadow: true
    subtitleCursive: true
    spaceBetweenTitleSubtitle: 20
---
